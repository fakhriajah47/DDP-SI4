from animals import Animal

class Ular(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, panjang_ular, jenis_ular):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.panjang_ular = panjang_ular
        self.jenis_ular = jenis_ular

    def cetak_ular(self):
        super().cetak()
        print(f"Panjang ular: {self.panjang_ular} meter dan jenis ular ini {self.jenis_ular}")

# Membuat objek ular
piton = Ular('Piton', 'Mamalia', 'Daratan', 'Bertelur', 5, 'Python')
kobra = Ular('Kobra', 'Mamalia', 'Hutan', 'Bertelur', 3, 'Kobra')

# Memanggil method cetak_ular
piton.cetak_ular()
kobra.cetak_ular()
