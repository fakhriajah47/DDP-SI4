class Animal:
    def __init__(self, nama, makanan, hidup, berkembang_biak):
        self.nama = nama
        self.makanan = makanan
        self.hidup = hidup
        self.berkembang_biak = berkembang_biak

    def cetak(self):
        # Perbaiki penulisan string format
        print(f'Hewan {self.nama} ini memakan {self.makanan}, jenis hewan ini adalah {self.hidup} dan berkembang biak dengan cara {self.berkembang_biak}')

# # Membuat objek dan memanggil metode cetak
# c1 = Animal('Buaya', 'Daging', 'Amphibi', 'Bertelur')
# c1.cetak()  # Pemanggilan tanpa self

# c2 = Animal ('ayam', 'biji-bijian', 'karnifora', 'Bertelur')
# c2.cetak()
# anjing = Animal()
